package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication //@Configuration,@ComponentScan,@EnableAutoConfiguration
public class EmployeeCrudApplication {
	public static void main(String[] args) {
		SpringApplication.run(EmployeeCrudApplication.class, args);
	}

	
}
