package com.example.demo;

public class Student {
	private int studentId;
	private String stuName;
	private int stuMarks;
	private String stuAddress;

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public int getStuMarks() {
		return stuMarks;
	}

	public void setStuMarks(int stuMarks) {
		this.stuMarks = stuMarks;
	}

	public String getStuAddress() {
		return stuAddress;
	}

	public void setStuAddress(String stuAddress) {
		this.stuAddress = stuAddress;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", stuName=" + stuName + ", stuMarks=" + stuMarks + ", stuAddress="
				+ stuAddress + "]";
	}

	public Student(int studentId, String stuName, int stuMarks, String stuAddress) {
		super();
		this.studentId = studentId;
		this.stuName = stuName;
		this.stuMarks = stuMarks;
		this.stuAddress = stuAddress;
	}

	public Student() {
		// TODO Auto-generated constructor stub
	}
}
