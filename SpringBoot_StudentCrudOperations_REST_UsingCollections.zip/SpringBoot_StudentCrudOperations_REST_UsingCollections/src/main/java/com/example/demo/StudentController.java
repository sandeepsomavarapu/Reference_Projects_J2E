package com.example.demo;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/students")
public class StudentController {
	Set<Student> students = new HashSet<>();

	public StudentController() {
		students.add(new Student(123, "suresh", 250, "hyderabad"));
		students.add(new Student(234, "naresh", 350, "delhi"));
		students.add(new Student(345, "suresh", 600, "banglore"));
		students.add(new Student(456, "ramesh", 850, "hyderabad"));
		students.add(new Student(489, "rajesh", 635, "banglore"));
		students.add(new Student(471, "somesh", 545, "hyderabad"));
	}

	@GetMapping("/message")
	public String getMessage() { // http://localhost:1112/students/message
		return "welcome to spring boot REST";
	}

	@GetMapping("/getStudents")
	public Set<Student> getStudents() { // http://localhost:1112/students/getStudents
		return students;
	}

	@GetMapping("/getStudent/{id}")
	public Student getStudentId(@PathVariable("id") int stuId) { // http://localhost:1112/students/getStudent/123
		Optional<Student> optional = students.stream().filter(stu -> stu.getStudentId() == stuId).findAny();
		return optional.get();
	}

	@GetMapping("/getStudentsByAdd/{add}")
	public List<Student> getStudentByAdd(@PathVariable("add") String stuAdd) { // http://localhost:1112/students/getStudentsByAdd/hyderabad
		List<Student> list = students.stream().filter(stu -> stu.getStuAddress().equals(stuAdd))
				.collect(Collectors.toList());
		return list;
	}

	@GetMapping("/getStudentsBetween/{m1}/{m2}")
	public List<Student> getStudentsBetween(@PathVariable("m1") int marks, @PathVariable("m2") int marks1) { // http://localhost:1112/students/getStudentsBetween/500/600
		List<Student> list = students.stream().filter(stu -> stu.getStuMarks() >= marks && stu.getStuMarks() <= marks1)
				.collect(Collectors.toList());
		return list;
	}

	@PostMapping("/addStudent")
	public Set<Student> addStudent(@RequestBody Student student) { // http://localhost:1112/students/addStudent
		students.add(student);
		return students;
	}

	@PutMapping("/updateStudent")
	public Student updateStudent(@RequestBody Student student) { // http://localhost:1112/students/updateStudent
		Student exsistingStudent = getStudentId(student.getStudentId());
		exsistingStudent.setStuName(student.getStuName());
		exsistingStudent.setStuMarks(student.getStuMarks());
		exsistingStudent.setStuAddress(student.getStuAddress());
		students.remove(student);
		students.add(exsistingStudent);
		return exsistingStudent;
	}

	@DeleteMapping("/deleteStudent/{id}")
	public String deleteStudent(@PathVariable("id") int studentId) { // http://localhost:1112/students/deleteStudent/{id}
		Student exsistingStudent = getStudentId(studentId);
		students.remove(exsistingStudent);
		return "Student Deleted Successfully";
	}

}
