package com.excelr.productmanagement;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class ProductClient {
	public static void main(String[] args) {
		HashMap<Integer, Product> products = new HashMap<Integer, Product>();
		int productId;
		String productName;
		int productPrice;
		String productCategory;
		int productAvailability;
		Product product;
		Iterator<Integer> keys;
		Set<Integer> set;
		Scanner scan = new Scanner(System.in);
		
		while (true) {
			System.out.println("1) Add Product");
			System.out.println("2) Update Product");
			System.out.println("3) Delete Product");
			System.out.println("4) Get Product");
			System.out.println("5) Get All Products");
			System.out.println("6) Get All Products Between The Prices");
			System.out.println("7) Get All Products By Category");
			System.out.println("8) Exit");
			int option = scan.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Details For Add Product");
				System.out.println("Enter Product Id:");
				productId = scan.nextInt();
				System.out.println("Enter Product name:");
				productName = scan.next();
				System.out.println("Enter Product Price:");
				productPrice = scan.nextInt();
				System.out.println("Enter Product Category:");
				productCategory = scan.next();
				System.out.println("Enter Product Availabilty:");
				productAvailability = scan.nextInt();
				product = new Product(productId, productName, productPrice, productCategory, productAvailability);
				products.put(productId, product);
				System.out.println("Product Added Successfully");
				break;
			case 2:
				System.out.println("Enter Details For Update Product");
				System.out.println("Enter Exsisting Product Id:");
				productId = scan.nextInt();
				System.out.println("Enter Product name:");
				productName = scan.next();
				System.out.println("Enter Product Price:");
				productPrice = scan.nextInt();
				System.out.println("Enter Product Category:");
				productCategory = scan.next();
				System.out.println("Enter Product Availabilty:");
				productAvailability = scan.nextInt();
				product = new Product(productId, productName, productPrice, productCategory, productAvailability);
				products.put(productId, product);
				System.out.println("Product Updated Successfully");
				break;
			case 3:
				System.out.println("Enter Details For Delete Product");
				System.out.println("Enter Exsisting Product Id:");
				productId = scan.nextInt();
				products.remove(productId);
				System.out.println("Product Deleted Successfully");
				break;
			case 4:
				System.out.println("Enter Details For Get Product");
				System.out.println("Enter Exsisting Product Id:");
				productId = scan.nextInt();
				product = products.get(productId);
				System.out.println(product);
				break;
			case 5:
				set = products.keySet();
				keys = set.iterator();
				while (keys.hasNext()) {
					int key = keys.next();
					System.out.println(products.get(key));
				}
				break;
			case 6:
				System.out.println("Enter Product IntialPrice:");
				int intialPrice = scan.nextInt();
				System.out.println("Enter Product FinalPrice:");
				int finalPrice = scan.nextInt();
				set = products.keySet();
				keys = set.iterator();
				while (keys.hasNext()) {
					int key = keys.next();
					product = products.get(key);
					int exsistingPrice = product.getProductPrice();
					if (intialPrice <= exsistingPrice && exsistingPrice <= finalPrice)
						System.out.println(product);
				}
				break;
			case 7:
				System.out.println("Enter Product Category:");
				productCategory = scan.next();
				set = products.keySet();
				keys = set.iterator();
				while (keys.hasNext()) {
					int key = keys.next();
					product = products.get(key);
					String exsistingCategory = product.getProductCategory();
					if (exsistingCategory.equals(productCategory))
						System.out.println(product);
				}
				break;
			case 8:
				System.out.println("Thank You !!! ");
				scan.close();
				System.exit(0);
				break;
			}
		}
	}
}
