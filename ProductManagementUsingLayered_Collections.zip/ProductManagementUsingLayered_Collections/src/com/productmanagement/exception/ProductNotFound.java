package com.productmanagement.exception;

public class ProductNotFound extends Exception {
	public ProductNotFound(String message) {
		super(message);
	}
}
