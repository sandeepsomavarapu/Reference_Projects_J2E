package com.example.demo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.example.demo.exceptions.ProductNotFound;
import com.example.demo.model.Product;

@Repository
public class ProductDaoImpl implements ProductDao {

	@PersistenceContext
	EntityManager entityManger;

	@Override
	public String addProduct(Product product) {
		entityManger.persist(product);
		return "Product Added Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		entityManger.merge(product);
		return "Product Updated Successfully";
	}

	@Override
	public String deleteProduct(int productId) {
		Product product = getProduct(productId);
		if (product != null) {
			entityManger.remove(product);
			return "Product Removed Successfully";
		} else {
			throw new ProductNotFound("The Product Id Is Invalid");
		}
	}

	@Override
	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		return entityManger.find(Product.class, productId);
	}

	@Override
	public List<Product> getAllProducts() {
		TypedQuery<Product> result = entityManger.createQuery("select p from Product p", Product.class);

		return result.getResultList();
	}

}
