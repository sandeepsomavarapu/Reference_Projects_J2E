package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "products_info")
public class Product {
	@Id
	@Min(value = 100,message="Enter Valid Product Id above 100")
	private int productId;
	@NotEmpty(message = "ProductName Is Mandatory and can't be empty")
	private String productName;
	@Min(value = 10,message = "Price cannot be below 10 and above 100000")
	@Max(value=100000)
	private int productPrice;
	private String productDesc;

	public Product() {
		// TODO Auto-generated constructor stub
	}

	public Product(int productId, String productName, int productPrice, String productDesc) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productDesc = productDesc;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

}
