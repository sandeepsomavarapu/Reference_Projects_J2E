package com.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@ComponentScan("com.gol.springcore")
public class CLient {
	public static void main(String[] args) {

		ApplicationContext factory = new AnnotationConfigApplicationContext(CLient.class);

		Employee emp = (Employee) factory.getBean("employee");
		Employee emp1 = (Employee) factory.getBean("employee");
		System.out.println(emp);
		System.out.println(emp1);
		System.out.println(emp.getAddress());
	}
	@Bean("employee")//<bean>
	public Employee getEmployee()
	{
		Employee emp= new Employee();
		emp.setAddress(getAddress());
		return emp;
	}
	@Bean("add")
	public Address getAddress()
	{
		return new Address();
	}
}
