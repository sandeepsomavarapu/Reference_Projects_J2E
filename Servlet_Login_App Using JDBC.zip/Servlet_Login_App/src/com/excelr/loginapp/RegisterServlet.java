package com.excelr.loginapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//create table users(userid int,username varchar(15),password varchar(15),contact bigint);

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		int userId = Integer.parseInt(request.getParameter("uid"));
		String username = request.getParameter("uname");
		String password = request.getParameter("pass");
		long contact = Long.parseLong(request.getParameter("contact"));

		Connection conn = DBConnection.getConnection();

		try {
			PreparedStatement psmt = conn.prepareStatement("insert into users values(?,?,?,?)");
			psmt.setInt(1, userId);
			psmt.setString(2, username);
			psmt.setString(3, password);
			psmt.setLong(4, contact);
			int result = psmt.executeUpdate();

			if (result > 0) {
				out.println("Registered Successfully");
			}
			conn.close();
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

}
