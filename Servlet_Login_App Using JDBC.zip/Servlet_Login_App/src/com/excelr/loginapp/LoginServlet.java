package com.excelr.loginapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//create table users(userid int,username varchar(15),password varchar(15),contact bigint);

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String username = request.getParameter("uname");
		String password = request.getParameter("pass");

		Connection conn = DBConnection.getConnection();

		try {
			PreparedStatement psmt = conn.prepareStatement("select * from users where username=? and password=?");

			psmt.setString(1, username);
			psmt.setString(2, password);

			ResultSet result = psmt.executeQuery();

			if (result.next()) {
				RequestDispatcher rd=request.getRequestDispatcher("home.html");
							rd.forward(request, response);
			} else {
				RequestDispatcher rd=request.getRequestDispatcher("login.html");
				rd.include(request, response);
				out.println("Enter Valid Credentials");
			}
			conn.close();
		} catch (Exception e) {

			e.printStackTrace();
		}

	}
}
