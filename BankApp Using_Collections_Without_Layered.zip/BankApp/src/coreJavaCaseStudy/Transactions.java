package coreJavaCaseStudy;

import java.util.Date;

public class Transactions {
	
	private long transId;
	
	private long accNoFrom;
	
	private long accNoTo;
	
	private float ammout;
	
	private Date dateOfTrans;
	
	private String Transtype;
	
	private float balance;
	
	public Transactions() {
		// TODO Auto-generated constructor stub
	}

	public long getTransId() {
		return transId;
	}

	public void setTransId(long transId) {
		this.transId = transId;
	}

	public long getAccNoFrom() {
		return accNoFrom;
	}

	public void setAccNoFrom(long accNoFrom) {
		this.accNoFrom = accNoFrom;
	}

	public long getAccNoTo() {
		return accNoTo;
	}

	public void setAccNoTo(long accNoTo) {
		this.accNoTo = accNoTo;
	}

	public float getAmmout() {
		return ammout;
	}

	public void setAmmout(float ammout) {
		this.ammout = ammout;
	}

	public Date getDateOfTrans() {
		return dateOfTrans;
	}

	public void setDateOfTrans(Date dateOfTrans) {
		this.dateOfTrans = dateOfTrans;
	}

	public String getTranstype() {
		return Transtype;
	}

	public void setTranstype(String transtype) {
		Transtype = transtype;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public Transactions(long transId, long accNoFrom, long accNoTo, float ammout, Date dateOfTrans, String transtype,
			float balance) {
		super();
		this.transId = transId;
		this.accNoFrom = accNoFrom;
		this.accNoTo = accNoTo;
		this.ammout = ammout;
		this.dateOfTrans = dateOfTrans;
		Transtype = transtype;
		this.balance = balance;
	}
	
	
	
	
	

}
