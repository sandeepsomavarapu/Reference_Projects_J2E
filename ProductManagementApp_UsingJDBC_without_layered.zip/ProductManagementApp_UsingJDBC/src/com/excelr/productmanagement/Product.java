package com.excelr.productmanagement;

public class Product {
	private int productId;
	private String productName;
	private int productPrice;
	private String productCategory;
	private int productAvailability;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public int getProductAvailability() {
		return productAvailability;
	}

	public void setProductAvailability(int productAvailability) {
		this.productAvailability = productAvailability;
	}

	public Product(int productId, String productName, int productPrice, String productCategory,
			int productAvailability) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productCategory = productCategory;
		this.productAvailability = productAvailability;
	}

	public Product() {
		
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", productCategory=" + productCategory + ", productAvailability=" + productAvailability + "]";
	}

}
