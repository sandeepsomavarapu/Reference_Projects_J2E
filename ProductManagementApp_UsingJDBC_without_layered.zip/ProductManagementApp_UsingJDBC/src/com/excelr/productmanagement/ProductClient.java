package com.excelr.productmanagement;

//create table products_info(productid int,productname varchar(20),productprice int,productcategory varchar(20),productavailabily int);
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ProductClient {
	// making database connection
	static Connection conn;
	static {

		// loading the driver class
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			// create the connection
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/excelr_weekend", "root", "rpsconsulting");
		} catch (ClassNotFoundException | SQLException e) {

			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws SQLException {

		int productId;
		String productName;
		int productPrice;
		String productCategory;
		int productAvailability;
		PreparedStatement psmt;
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println("1) Add Product");
			System.out.println("2) Update Product");
			System.out.println("3) Delete Product");
			System.out.println("4) Get Product");
			System.out.println("5) Get All Products");
			System.out.println("6) Get All Products Between The Prices");
			System.out.println("7) Get All Products By Category");
			System.out.println("8) Exit");
			// taking here end user option
			int option = scan.nextInt();
			switch (option) {
			case 1:
				// collecting product details from end user
				System.out.println("Enter Details For Add Product");
				System.out.println("Enter Product Id:");
				productId = scan.nextInt();
				System.out.println("Enter Product name:");
				productName = scan.next();
				System.out.println("Enter Product Price:");
				productPrice = scan.nextInt();
				System.out.println("Enter Product Category:");
				productCategory = scan.next();
				System.out.println("Enter Product Availabilty:");
				productAvailability = scan.nextInt();
				psmt = conn.prepareStatement("insert into products_info values(?,?,?,?,?)");
				// setting dynamic data collected from end user to insert query
				psmt.setInt(1, productId);
				psmt.setString(2, productName);
				psmt.setInt(3, productPrice);
				psmt.setString(4, productCategory);
				psmt.setInt(5, productAvailability);
				int result = psmt.executeUpdate();
				if (result == 1) {
					System.out.println("Product Saved Successfully");
				} else {
					System.out.println("Something Wrong");
				}
				break;
			case 2:
				System.out.println("Enter Details For Update Product");
				System.out.println("Enter Exsisting Product Id:");
				productId = scan.nextInt();
				System.out.println("Enter Product name:");
				productName = scan.next();
				System.out.println("Enter Product Price:");
				productPrice = scan.nextInt();
				System.out.println("Enter Product Category:");
				productCategory = scan.next();
				System.out.println("Enter Product Availabilty:");
				productAvailability = scan.nextInt();
				psmt = conn.prepareStatement(
						"update products_info set productname=?,productprice=?,productcategory=?,productavailabity=? where productid=?");
				// setting dynamic data collected from end user to insert query
				psmt.setString(1, productName);
				psmt.setInt(2, productPrice);
				psmt.setString(3, productCategory);
				psmt.setInt(4, productAvailability);
				psmt.setInt(5, productId);
				result = psmt.executeUpdate();
				if (result == 1) {
					System.out.println("Product Updated Successfully");
				} else {
					System.out.println("Something Wrong");
				}
				break;
			case 3:
				System.out.println("Enter Details For Delete Product");
				System.out.println("Enter Exsisting Product Id:");
				productId = scan.nextInt();
				psmt = conn.prepareStatement("delete from products_info where productid=?");
				// setting dynamic data collected from end user to insert query
				psmt.setInt(1, productId);
				result = psmt.executeUpdate();
				if (result == 1) {
					System.out.println("Product Deleted Successfully");
				} else {
					System.out.println("Something Wrong");
				}
				break;
			case 4:
				System.out.println("Enter Details For Get Product");
				System.out.println("Enter Exsisting Product Id:");
				productId = scan.nextInt();
				psmt = conn.prepareStatement("select * from products_info where productid=?");
				// setting dynamic data collected from end user to insert query
				psmt.setInt(1, productId);
				ResultSet resultSet = psmt.executeQuery();
				if (resultSet.next()) {
					System.out.println(resultSet.getInt(1) + " " + resultSet.getString(2) + " " + resultSet.getInt(3)
							+ " " + resultSet.getString(4) + " " + resultSet.getInt(5));
				} else {
					System.out.println("Something Wrong");
				}
				break;
			case 5:
				psmt = conn.prepareStatement("select * from products_info");
				// setting dynamic data collected from end user to insert query
				resultSet = psmt.executeQuery();
				while (resultSet.next()) {
					System.out.println(resultSet.getInt(1) + " " + resultSet.getString(2) + " " + resultSet.getInt(3)
							+ " " + resultSet.getString(4) + " " + resultSet.getInt(5));
				}

				break;
			case 6:
				System.out.println("Enter Product IntialPrice:");
				int intialPrice = scan.nextInt();
				System.out.println("Enter Product FinalPrice:");
				int finalPrice = scan.nextInt();
				psmt = conn.prepareStatement("select * from products_info where productprice between ? and ?");
				// setting dynamic data collected from end user to insert query
				psmt.setInt(1, intialPrice);
				psmt.setInt(2, finalPrice);
				resultSet = psmt.executeQuery();
				while (resultSet.next()) {
					System.out.println(resultSet.getInt(1) + " " + resultSet.getString(2) + " " + resultSet.getInt(3)
							+ " " + resultSet.getString(4) + " " + resultSet.getInt(5));
				}

				break;
			case 7:
				System.out.println("Enter Product Category:");
				productCategory = scan.next();
				psmt = conn.prepareStatement("select * from products_info where productcategory=?");
				// setting dynamic data collected from end user to insert query
				psmt.setString(1, productCategory);
				resultSet = psmt.executeQuery();
				while (resultSet.next()) {
					System.out.println(resultSet.getInt(1) + " " + resultSet.getString(2) + " " + resultSet.getInt(3)
							+ " " + resultSet.getString(4) + " " + resultSet.getInt(5));
				}

				break;
			case 8:
				System.out.println("Thank You !!! ");
				scan.close();
				System.exit(0);
				break;
			}
		}
	}
}
